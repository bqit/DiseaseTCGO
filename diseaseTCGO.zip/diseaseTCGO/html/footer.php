<footer>
    <p>	
        Disease TCGO è stato creato da Pietro Battistini. 
        <a target="_blank" href="https://byteportfolio.altervista.org/PortfolioWebsite/html/indexEn.html">Controlla i miei altri lavori</a>.
        v.01.00.0
        <button id="button" class="themeButton" onclick="show_themes()"><i class="fa-solid fa-palette"></i> DTCGO default</button>
    </p>
</footer>